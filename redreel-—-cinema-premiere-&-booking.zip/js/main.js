/* ==========================================================================
   REDREEL — NIGHTSHADE II
   Vanilla JavaScript Interactions, Parallax, Booking Engine & Cutout Processor
   ========================================================================== */

(function () {
  "use strict";

  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ------------------------------------------------------------------------
     Movie Catalog Data (Single Source of Truth for Search & Booking)
  ------------------------------------------------------------------------ */
  const MOVIES = {
    nightshade: {
      id: "nightshade",
      title: "Nightshade II",
      genres: "Action · Thriller · Sci-Fi",
      cast: "Marcus Hale, Lena Okafor, Dario Voss, Priya Raman",
      poster: "./images/poster-nightshade.jpg",
      screen: "Screen 01",
      times: ["17:00", "18:30", "20:15", "22:45"],
    },
    solaris: {
      id: "solaris",
      title: "Solaris Drift",
      genres: "Sci-Fi · Thriller",
      cast: "Julian Vance, Mara Klein",
      poster: "./images/poster-solaris.jpg",
      screen: "Screen 02",
      times: ["17:00", "19:45", "22:15", "23:30"],
    },
    "ash-chrome": {
      id: "ash-chrome",
      title: "Ash & Chrome",
      genres: "Action · Heist",
      cast: "Devon Reyes, Claire Sato",
      poster: "./images/poster-ash-chrome.jpg",
      screen: "Screen 04",
      times: ["16:15", "19:00", "21:30", "23:15"],
    },
    "zero-meridian": {
      id: "zero-meridian",
      title: "Zero Meridian",
      genres: "Thriller · Action",
      cast: "Soren Lindqvist, Eva Thorne",
      poster: "./images/poster-zero-meridian.jpg",
      screen: "Screen 03",
      times: ["15:45", "18:45", "21:15", "22:50"],
    },
    "glass-protocol": {
      id: "glass-protocol",
      title: "Glass Protocol",
      genres: "Mystery · Thriller",
      cast: "Nadia Sorin, Miles Kovic",
      poster: "./images/poster-glass-protocol.jpg",
      screen: "VIP Screen 05",
      times: ["17:30", "20:00", "22:30", "23:45"],
    },
  };

  /* ------------------------------------------------------------------------
     1. Hero Character Background Cutout (Opaque VANTA over Red Circle & Title)
  ------------------------------------------------------------------------ */
  function initHeroCharacterCutout() {
    const img = document.getElementById("heroCharacterImg");
    if (!img) return;

    img.classList.add("is-raw-fallback");

    const sourceImg = new Image();
    sourceImg.src = img.getAttribute("src") || "./images/hero-vanta.jpg";

    sourceImg.onload = function () {
      try {
        const w = sourceImg.naturalWidth;
        const h = sourceImg.naturalHeight;
        if (!w || !h) return;

        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        if (!ctx) return;

        ctx.drawImage(sourceImg, 0, 0);
        const imageData = ctx.getImageData(0, 0, w, h);
        const data = imageData.data;

        const total = w * h;
        const visited = new Uint8Array(total);
        const queue = new Int32Array(total);
        let head = 0;
        let tail = 0;

        const isNearBlack = (idx4) =>
          data[idx4] < 16 && data[idx4 + 1] < 16 && data[idx4 + 2] < 16;

        // Seed flood fill from all 4 image boundaries
        for (let x = 0; x < w; x++) {
          const topIdx = x;
          if (isNearBlack(topIdx * 4)) {
            visited[topIdx] = 1;
            queue[tail++] = topIdx;
          }
          const botIdx = (h - 1) * w + x;
          if (!visited[botIdx] && isNearBlack(botIdx * 4)) {
            visited[botIdx] = 1;
            queue[tail++] = botIdx;
          }
        }
        for (let y = 1; y < h - 1; y++) {
          const leftIdx = y * w;
          if (!visited[leftIdx] && isNearBlack(leftIdx * 4)) {
            visited[leftIdx] = 1;
            queue[tail++] = leftIdx;
          }
          const rightIdx = y * w + (w - 1);
          if (!visited[rightIdx] && isNearBlack(rightIdx * 4)) {
            visited[rightIdx] = 1;
            queue[tail++] = rightIdx;
          }
        }

        // BFS flood fill exterior pitch-black pixels only (preserves dark interior armor)
        while (head < tail) {
          const p = queue[head++];
          const x = p % w;
          const y = (p - x) / w;

          if (x > 0) {
            const n = p - 1;
            if (!visited[n] && isNearBlack(n * 4)) {
              visited[n] = 1;
              queue[tail++] = n;
            }
          }
          if (x < w - 1) {
            const n = p + 1;
            if (!visited[n] && isNearBlack(n * 4)) {
              visited[n] = 1;
              queue[tail++] = n;
            }
          }
          if (y > 0) {
            const n = p - w;
            if (!visited[n] && isNearBlack(n * 4)) {
              visited[n] = 1;
              queue[tail++] = n;
            }
          }
          if (y < h - 1) {
            const n = p + w;
            if (!visited[n] && isNearBlack(n * 4)) {
              visited[n] = 1;
              queue[tail++] = n;
            }
          }
        }

        // Apply transparency and 1px edge anti-aliasing
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const p = y * w + x;
            const i4 = p * 4;
            if (visited[p]) {
              data[i4 + 3] = 0;
            } else {
              const touchesBg =
                (x > 0 && visited[p - 1]) ||
                (x < w - 1 && visited[p + 1]) ||
                (y > 0 && visited[p - w]) ||
                (y < h - 1 && visited[p + w]);
              if (touchesBg) {
                const maxC = Math.max(data[i4], data[i4 + 1], data[i4 + 2]);
                data[i4 + 3] = Math.min(255, Math.max(48, Math.round((maxC / 44) * 255)));
              }
            }
          }
        }

        ctx.putImageData(imageData, 0, 0);
        canvas.toBlob(function (blob) {
          if (!blob) return;
          const url = URL.createObjectURL(blob);
          img.src = url;
          img.classList.remove("is-raw-fallback");
        }, "image/png");
      } catch (_err) {
        // Retain fallback blend safely if canvas is restricted
      }
    };
  }

  /* ------------------------------------------------------------------------
     2. Scroll Progress, Sticky Header, Active Nav & Mobile Sticky CTA
  ------------------------------------------------------------------------ */
  function initScrollAndNav() {
    const progressEl = document.getElementById("scrollProgress");
    const header = document.getElementById("siteHeader");
    const mobileStickyCta = document.getElementById("mobileStickyCta");
    const navLinks = Array.from(document.querySelectorAll(".nav-link[data-nav-target]"));
    const trackedSections = navLinks
      .map((link) => document.getElementById(link.dataset.navTarget))
      .filter(Boolean);

    let ticking = false;

    function updateOnScroll() {
      const scrollY = window.scrollY || window.pageYOffset;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = docHeight > 0 ? Math.min(1, Math.max(0, scrollY / docHeight)) : 0;

      if (progressEl) {
        progressEl.style.transform = `scaleX(${progress.toFixed(4)})`;
      }

      if (header) {
        header.classList.toggle("is-scrolled", scrollY > 36);
      }

      if (mobileStickyCta) {
        const footer = document.querySelector(".site-footer");
        const footerTop = footer ? footer.getBoundingClientRect().top : Infinity;
        const showSticky = scrollY > 420 && footerTop > window.innerHeight + 60;
        mobileStickyCta.classList.toggle("is-visible", showSticky);
      }

      // Active section indicator
      let currentId = "now-showing";
      const offset = (header ? header.offsetHeight : 68) + 120;
      for (const sec of trackedSections) {
        if (sec.getBoundingClientRect().top <= offset) {
          currentId = sec.id;
        }
      }
      navLinks.forEach((link) => {
        link.classList.toggle("is-active", link.dataset.navTarget === currentId);
      });

      ticking = false;
    }

    window.addEventListener(
      "scroll",
      function () {
        if (!ticking) {
          window.requestAnimationFrame(updateOnScroll);
          ticking = true;
        }
      },
      { passive: true }
    );
    updateOnScroll();

    // Smooth scroll with sticky header offset
    document.addEventListener("click", function (e) {
      const anchor = e.target.closest('a[href^="#"]');
      if (!anchor) return;
      const href = anchor.getAttribute("href");
      if (!href || href === "#") return;
      const target = document.querySelector(href);
      if (!target) return;

      e.preventDefault();
      const headerHeight = header ? header.offsetHeight : 0;
      const top = target.getBoundingClientRect().top + window.scrollY - headerHeight - 8;
      window.scrollTo({
        top: Math.max(0, top),
        behavior: prefersReducedMotion ? "auto" : "smooth",
      });
    });
  }

  /* ------------------------------------------------------------------------
     3. Custom Cursor Ring (Desktop Pointer Only)
  ------------------------------------------------------------------------ */
  function initCursorRing() {
    const ring = document.getElementById("cursorRing");
    if (!ring || prefersReducedMotion) return;
    if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;

    let mouseX = -100;
    let mouseY = -100;
    let ringX = -100;
    let ringY = -100;
    let rafId = null;

    function animate() {
      ringX += (mouseX - ringX) * 0.22;
      ringY += (mouseY - ringY) * 0.22;
      const offset = ring.classList.contains("is-hover") ? 28 : 17;
      ring.style.transform = `translate3d(${ringX - offset}px, ${ringY - offset}px, 0)`;
      rafId = window.requestAnimationFrame(animate);
    }

    document.addEventListener("pointermove", function (e) {
      mouseX = e.clientX;
      mouseY = e.clientY;
      if (!ring.classList.contains("is-visible")) {
        ring.classList.add("is-visible");
        rafId = window.requestAnimationFrame(animate);
      }
      const interactive = e.target.closest("a, button, select, input, .movie-card, .cast-card");
      ring.classList.toggle("is-hover", Boolean(interactive));
    });

    document.addEventListener("pointerleave", function () {
      ring.classList.remove("is-visible");
      if (rafId) {
        window.cancelAnimationFrame(rafId);
        rafId = null;
      }
    });
  }

  /* ------------------------------------------------------------------------
     4. Hero Mouse-Move Parallax
  ------------------------------------------------------------------------ */
  function initHeroParallax() {
    if (prefersReducedMotion) return;
    const hero = document.getElementById("hero");
    const circle = document.getElementById("heroRedCircle");
    const charWrap = document.getElementById("heroCharacterWrap");
    if (!hero || !circle || !charWrap) return;
    if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;

    hero.addEventListener("pointermove", function (e) {
      const rect = hero.getBoundingClientRect();
      const nx = (e.clientX - rect.left) / rect.width - 0.5;
      const ny = (e.clientY - rect.top) / rect.height - 0.5;

      circle.style.transform = `translate(calc(-50% + ${(-nx * 24).toFixed(1)}px), calc(-50% + ${(-ny * 18).toFixed(1)}px))`;
      charWrap.style.transform = `translate(calc(-50% + ${(nx * 18).toFixed(1)}px), ${(ny * 10).toFixed(1)}px)`;
    });

    hero.addEventListener("pointerleave", function () {
      circle.style.transform = "translate(-50%, -50%)";
      charWrap.style.transform = "translate(-50%, 0)";
    });
  }

  /* ------------------------------------------------------------------------
     5. Button Ripple Feedback
  ------------------------------------------------------------------------ */
  function initButtonRipples() {
    document.addEventListener("click", function (e) {
      const btn = e.target.closest(".btn");
      if (!btn || prefersReducedMotion) return;
      const rect = btn.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const ripple = document.createElement("span");
      ripple.className = "btn-ripple";
      ripple.style.width = `${size}px`;
      ripple.style.height = `${size}px`;
      ripple.style.left = `${e.clientX - rect.left - size / 2}px`;
      ripple.style.top = `${e.clientY - rect.top - size / 2}px`;
      btn.appendChild(ripple);
      window.setTimeout(() => ripple.remove(), 600);
    });
  }

  /* ------------------------------------------------------------------------
     6. Scroll Reveal & Animated Stats Count-Up
  ------------------------------------------------------------------------ */
  function initScrollReveals() {
    const revealEls = document.querySelectorAll(".reveal-up");
    if (!("IntersectionObserver" in window) || prefersReducedMotion) {
      revealEls.forEach((el) => el.classList.add("is-visible"));
    } else {
      const revealObserver = new IntersectionObserver(
        (entries, obs) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              obs.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.14, rootMargin: "0px 0px -30px 0px" }
      );
      revealEls.forEach((el) => revealObserver.observe(el));
    }

    // Count-Up Stats
    const statEls = document.querySelectorAll(".stat-num[data-count-target]");
    const runCountUp = (el) => {
      const target = parseFloat(el.dataset.countTarget || "0");
      const decimals = parseInt(el.dataset.decimals || "0", 10);
      const suffix = el.dataset.suffix || "";
      if (prefersReducedMotion) {
        el.textContent = target.toFixed(decimals) + suffix;
        return;
      }

      const duration = 1250;
      const start = performance.now();

      function step(now) {
        const t = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - t, 3);
        const val = target * eased;
        el.textContent = (decimals > 0 ? val.toFixed(decimals) : Math.round(val).toLocaleString()) + suffix;
        if (t < 1) {
          requestAnimationFrame(step);
        } else {
          el.textContent = (decimals > 0 ? target.toFixed(decimals) : target.toLocaleString()) + suffix;
        }
      }
      requestAnimationFrame(step);
    };

    if (!("IntersectionObserver" in window) || prefersReducedMotion) {
      statEls.forEach(runCountUp);
    } else {
      const statObserver = new IntersectionObserver(
        (entries, obs) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              runCountUp(entry.target);
              obs.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.35 }
      );
      statEls.forEach((el) => statObserver.observe(el));
    }
  }

  /* ------------------------------------------------------------------------
     7. Full-Screen Mobile Menu Overlay & Modals
  ------------------------------------------------------------------------ */
  function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function closeModal(modal) {
    if (!modal) return;
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  function initOverlaysAndModals() {
    const menuOverlay = document.getElementById("mobileOverlay");
    const openMenuBtn = document.getElementById("openMenuBtn");
    const closeMenuBtn = document.getElementById("closeMenuBtn");

    function setMenuOpen(open) {
      if (!menuOverlay) return;
      menuOverlay.classList.toggle("is-open", open);
      menuOverlay.setAttribute("aria-hidden", open ? "false" : "true");
      if (openMenuBtn) openMenuBtn.setAttribute("aria-expanded", open ? "true" : "false");
      document.body.style.overflow = open ? "hidden" : "";
    }

    if (openMenuBtn) openMenuBtn.addEventListener("click", () => setMenuOpen(true));
    if (closeMenuBtn) closeMenuBtn.addEventListener("click", () => setMenuOpen(false));
    if (menuOverlay) {
      menuOverlay.querySelectorAll("a").forEach((link) => {
        link.addEventListener("click", () => setMenuOpen(false));
      });
    }

    // Modal Triggers
    const openTrailerBtn = document.getElementById("openTrailerBtn");
    const heroBadgeBtn = document.getElementById("heroBadgeBtn");
    if (openTrailerBtn) openTrailerBtn.addEventListener("click", () => openModal("trailerModal"));
    if (heroBadgeBtn) heroBadgeBtn.addEventListener("click", () => openModal("trailerModal"));

    const openSearchBtn = document.getElementById("openSearchBtn");
    const searchInput = document.getElementById("filmSearchInput");
    if (openSearchBtn) {
      openSearchBtn.addEventListener("click", () => {
        openModal("searchModal");
        renderSearchResults("");
        window.setTimeout(() => searchInput && searchInput.focus(), 60);
      });
    }

    // Close Modal Buttons & Backdrop Click
    document.querySelectorAll("[data-close-modal]").forEach((btn) => {
      btn.addEventListener("click", () => {
        closeModal(document.getElementById(btn.dataset.closeModal));
      });
    });

    document.querySelectorAll(".modal-backdrop").forEach((backdrop) => {
      backdrop.addEventListener("click", (e) => {
        if (e.target === backdrop) closeModal(backdrop);
      });
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        setMenuOpen(false);
        document.querySelectorAll(".modal-backdrop.is-open").forEach(closeModal);
      }
    });

    // Legal Modals (Privacy / Terms)
    document.querySelectorAll(".legal-link-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const type = btn.dataset.legal;
        const kicker = document.getElementById("passModalKicker");
        const title = document.getElementById("passModalTitle");
        const body = document.getElementById("passModalBody");
        if (!kicker || !title || !body) return;

        kicker.textContent = "REDREEL Legal";
        title.textContent = type === "privacy" ? "Privacy Policy" : "Terms of Admission";
        body.innerHTML =
          type === "privacy"
            ? `<p style="color:var(--muted);margin:0;">REDREEL collects only the email address and ticket preference details you submit to reserve seats or receive premiere alerts. No third-party ad trackers are embedded on this booking page.</p>`
            : `<p style="color:var(--muted);margin:0;">Doors open 25 minutes prior to posted showtimes. Seat exchanges and full refunds are available up to 2 hours before screening start via your digital pass code.</p>`;
        openModal("passModal");
      });
    });
  }

  /* ------------------------------------------------------------------------
     8. Search Modal Logic
  ------------------------------------------------------------------------ */
  function renderSearchResults(query) {
    const container = document.getElementById("searchResults");
    if (!container) return;
    const q = query.trim().toLowerCase();

    const items = Object.values(MOVIES).filter((m) => {
      if (!q) return true;
      return (
        m.title.toLowerCase().includes(q) ||
        m.genres.toLowerCase().includes(q) ||
        m.cast.toLowerCase().includes(q)
      );
    });

    if (!items.length) {
      container.innerHTML = `<p style="color:var(--muted);margin:8px 0;">No features or cast matched "${query}".</p>`;
      return;
    }

    container.innerHTML = items
      .map(
        (m) => `
      <button type="button" class="search-result-item" data-search-movie="${m.id}">
        <div>
          <p class="search-result-title">${m.title}</p>
          <p class="search-result-sub">${m.genres} &middot; ${m.cast}</p>
        </div>
        <span class="btn btn-primary btn-sm">Book</span>
      </button>
    `
      )
      .join("");
  }

  function initSearch(selectMovieFn) {
    const input = document.getElementById("filmSearchInput");
    const container = document.getElementById("searchResults");
    if (input) {
      input.addEventListener("input", () => renderSearchResults(input.value));
    }
    if (container) {
      container.addEventListener("click", (e) => {
        const btn = e.target.closest("[data-search-movie]");
        if (!btn) return;
        const movieId = btn.dataset.searchMovie;
        closeModal(document.getElementById("searchModal"));
        selectMovieFn(movieId);
        const ticketsEl = document.getElementById("tickets");
        const header = document.getElementById("siteHeader");
        if (ticketsEl) {
          const top = ticketsEl.getBoundingClientRect().top + window.scrollY - (header ? header.offsetHeight : 0) - 8;
          window.scrollTo({ top, behavior: prefersReducedMotion ? "auto" : "smooth" });
        }
      });
    }
  }

  /* ------------------------------------------------------------------------
     9. Genre Filtering & Interactive Booking Engine
  ------------------------------------------------------------------------ */
  function initCatalogAndBooking() {
    const filterTabs = Array.from(document.querySelectorAll(".filter-tab[data-filter]"));
    const movieCards = Array.from(document.querySelectorAll(".movie-card[data-genres]"));

    function applyGenreFilter(genre) {
      filterTabs.forEach((tab) => {
        const active = tab.dataset.filter === genre;
        tab.classList.toggle("is-active", active);
        tab.setAttribute("aria-selected", active ? "true" : "false");
      });

      movieCards.forEach((card) => {
        const genres = (card.dataset.genres || "").split(",");
        const show = genre === "all" || genres.includes(genre);
        card.classList.toggle("is-hidden", !show);
      });
    }

    filterTabs.forEach((tab) => {
      tab.addEventListener("click", () => applyGenreFilter(tab.dataset.filter));
    });

    // Hero genre pills jump to Now Showing and filter
    document.querySelectorAll(".genre-pill[data-genre-jump]").forEach((pill) => {
      pill.addEventListener("click", () => {
        applyGenreFilter(pill.dataset.genreJump);
        const section = document.getElementById("now-showing");
        const header = document.getElementById("siteHeader");
        if (section) {
          const top = section.getBoundingClientRect().top + window.scrollY - (header ? header.offsetHeight : 0) - 8;
          window.scrollTo({ top, behavior: prefersReducedMotion ? "auto" : "smooth" });
        }
      });
    });

    // Booking State
    const state = {
      movieId: "nightshade",
      date: "Fri, Dec 12",
      format: "IMAX Laser",
      price: 24,
      time: "18:30",
      seats: 2,
      latestBooking: null,
    };

    const movieSelect = document.getElementById("bookingMovieSelect");
    const dateChips = Array.from(document.querySelectorAll(".date-chip"));
    const formatChips = Array.from(document.querySelectorAll(".format-chip"));
    const timeStrip = document.getElementById("bookingTimeStrip");
    const seatMinusBtn = document.getElementById("seatMinusBtn");
    const seatPlusBtn = document.getElementById("seatPlusBtn");
    const seatCountVal = document.getElementById("seatCountVal");

    const summaryPoster = document.getElementById("summaryPosterImg");
    const summaryTitle = document.getElementById("summaryMovieTitle");
    const summaryFormat = document.getElementById("summaryFormatText");
    const summaryDate = document.getElementById("summaryDate");
    const summaryTime = document.getElementById("summaryTime");
    const summarySeats = document.getElementById("summarySeats");
    const summaryTotal = document.getElementById("summaryTotal");

    function renderTimeOptions() {
      if (!timeStrip) return;
      const movie = MOVIES[state.movieId] || MOVIES.nightshade;
      if (!movie.times.includes(state.time)) {
        state.time = movie.times[0];
      }
      timeStrip.innerHTML = movie.times
        .map(
          (t) =>
            `<button type="button" class="time-select-chip${
              t === state.time ? " is-selected" : ""
            }" data-time="${t}">${t}</button>`
        )
        .join("");
    }

    function formatSeatRange(count) {
      const startSeat = 7;
      if (count === 1) return "1 Ticket (Row G · G7)";
      return `${count} Tickets (Row G · G${startSeat}–G${startSeat + count - 1})`;
    }

    function updateSummary() {
      const movie = MOVIES[state.movieId] || MOVIES.nightshade;
      const subtotal = state.seats * state.price;
      const total = subtotal + 2.5;

      if (summaryPoster) summaryPoster.src = movie.poster;
      if (summaryTitle) summaryTitle.textContent = movie.title;
      if (summaryFormat) summaryFormat.textContent = `${state.format} · ${movie.screen}`;
      if (summaryDate) summaryDate.textContent = state.date;
      if (summaryTime) summaryTime.textContent = state.time;
      if (summarySeats) summarySeats.textContent = formatSeatRange(state.seats);
      if (summaryTotal) summaryTotal.textContent = `$${total.toFixed(2)}`;
      if (seatCountVal) seatCountVal.textContent = String(state.seats);
    }

    function selectMovie(movieId, chosenTime) {
      if (!MOVIES[movieId]) return;
      state.movieId = movieId;
      if (movieSelect) movieSelect.value = movieId;
      if (chosenTime) state.time = chosenTime;
      renderTimeOptions();
      updateSummary();
    }

    if (movieSelect) {
      movieSelect.addEventListener("change", () => {
        selectMovie(movieSelect.value);
      });
    }

    dateChips.forEach((chip) => {
      chip.addEventListener("click", () => {
        dateChips.forEach((c) => c.classList.remove("is-selected"));
        chip.classList.add("is-selected");
        state.date = chip.dataset.date || state.date;
        updateSummary();
      });
    });

    formatChips.forEach((chip) => {
      chip.addEventListener("click", () => {
        formatChips.forEach((c) => c.classList.remove("is-selected"));
        chip.classList.add("is-selected");
        state.format = chip.dataset.format || state.format;
        state.price = parseFloat(chip.dataset.price || "24");
        updateSummary();
      });
    });

    if (timeStrip) {
      timeStrip.addEventListener("click", (e) => {
        const btn = e.target.closest(".time-select-chip");
        if (!btn) return;
        state.time = btn.dataset.time || state.time;
        renderTimeOptions();
        updateSummary();
      });
    }

    if (seatMinusBtn) {
      seatMinusBtn.addEventListener("click", () => {
        if (state.seats > 1) {
          state.seats -= 1;
          updateSummary();
        }
      });
    }

    if (seatPlusBtn) {
      seatPlusBtn.addEventListener("click", () => {
        if (state.seats < 8) {
          state.seats += 1;
          updateSummary();
        }
      });
    }

    // Wire Now Showing showtime chips & quick-book buttons
    document.addEventListener("click", (e) => {
      const timeChip = e.target.closest(".time-chip[data-movie]");
      const quickBook = e.target.closest(".quick-book-btn[data-movie], [data-book-movie]");
      const targetBtn = timeChip || quickBook;
      if (!targetBtn) return;

      const movieId = targetBtn.dataset.movie || targetBtn.dataset.bookMovie;
      const time = targetBtn.dataset.time;
      if (movieId) {
        selectMovie(movieId, time);
      }

      if (timeChip || quickBook.tagName === "BUTTON") {
        const ticketsEl = document.getElementById("tickets");
        const header = document.getElementById("siteHeader");
        if (ticketsEl) {
          const top = ticketsEl.getBoundingClientRect().top + window.scrollY - (header ? header.offsetHeight : 0) - 8;
          window.scrollTo({ top, behavior: prefersReducedMotion ? "auto" : "smooth" });
        }
      }
    });

    // Confirm Booking CTA & Header Member Pass Button
    const confirmBtn = document.getElementById("confirmBookingBtn");
    const openPassBtn = document.getElementById("openPassBtn");

    function showPassModal(booking) {
      const kicker = document.getElementById("passModalKicker");
      const title = document.getElementById("passModalTitle");
      const body = document.getElementById("passModalBody");
      if (!kicker || !title || !body) return;

      if (booking) {
        kicker.textContent = "Reservation Confirmed";
        title.textContent = booking.movieTitle;
        body.innerHTML = `
          <div class="pass-card">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
              <div>
                <p class="micro-label">Digital Entry Code</p>
                <div class="pass-code">${booking.code}</div>
              </div>
              <svg width="64" height="64" viewBox="0 0 64 64" fill="none" aria-hidden="true">
                <rect width="64" height="64" rx="10" fill="#FFFFFF"/>
                <rect x="8" y="8" width="16" height="16" fill="#0B0B0D"/>
                <rect x="40" y="8" width="16" height="16" fill="#0B0B0D"/>
                <rect x="8" y="40" width="16" height="16" fill="#0B0B0D"/>
                <rect x="28" y="10" width="8" height="8" fill="#E10E2B"/>
                <rect x="28" y="28" width="10" height="10" fill="#0B0B0D"/>
                <rect x="42" y="30" width="14" height="8" fill="#0B0B0D"/>
                <rect x="30" y="44" width="12" height="12" fill="#E10E2B"/>
                <rect x="46" y="46" width="10" height="10" fill="#0B0B0D"/>
              </svg>
            </div>
            <div class="pass-meta-grid">
              <div><span>Date &amp; Time</span>${booking.date} &middot; ${booking.time}</div>
              <div><span>Auditorium</span>${booking.format} (${booking.screen})</div>
              <div><span>Assigned Seats</span>${booking.seatsText}</div>
              <div><span>Total Paid</span>${booking.total}</div>
            </div>
          </div>
          <p style="margin:16px 0 0;font-size:0.86rem;color:var(--muted);">
            Present this QR pass at the REDREEL lobby kiosk or Premiere Lounge check-in desk.
          </p>
        `;
      } else {
        kicker.textContent = "REDREEL Premiere Club";
        title.textContent = "Member Priority Pass";
        body.innerHTML = `
          <div class="pass-card">
            <p class="micro-label">Member Tier · Obsidian</p>
            <div class="pass-code">RR-8840-VIP</div>
            <p style="margin:0;color:var(--muted);font-size:0.9rem;">
              No active screening reserved yet. Select a showtime below to attach a digital ticket to your pass.
            </p>
          </div>
          <div style="margin-top:18px;">
            <a href="#tickets" class="btn btn-primary btn-full" id="passJumpBookBtn">Reserve Seats Now &#8599;</a>
          </div>
        `;
        const jumpBtn = document.getElementById("passJumpBookBtn");
        if (jumpBtn) {
          jumpBtn.addEventListener("click", () => {
            closeModal(document.getElementById("passModal"));
          });
        }
      }

      openModal("passModal");
    }

    if (confirmBtn) {
      confirmBtn.addEventListener("click", () => {
        const movie = MOVIES[state.movieId] || MOVIES.nightshade;
        const total = (state.seats * state.price + 2.5).toFixed(2);
        const rand = Math.floor(1000 + Math.random() * 9000);
        state.latestBooking = {
          movieTitle: movie.title,
          screen: movie.screen,
          date: state.date,
          time: state.time,
          format: state.format,
          seatsText: formatSeatRange(state.seats),
          total: `$${total}`,
          code: `RR-${rand}-${movie.id.slice(0, 2).toUpperCase()}`,
        };
        showPassModal(state.latestBooking);
      });
    }

    if (openPassBtn) {
      openPassBtn.addEventListener("click", () => showPassModal(state.latestBooking));
    }

    renderTimeOptions();
    updateSummary();

    return selectMovie;
  }

  /* ------------------------------------------------------------------------
     10. Testimonials Carousel (Buttons, Dots, Touch Swipe)
  ------------------------------------------------------------------------ */
  function initTestimonials() {
    const track = document.getElementById("testimonialTrack");
    const viewport = document.getElementById("testimonialViewport");
    const prevBtn = document.getElementById("prevTestimonialBtn");
    const nextBtn = document.getElementById("nextTestimonialBtn");
    const dots = Array.from(document.querySelectorAll(".carousel-dot"));
    if (!track || !dots.length) return;

    let index = 0;
    const total = dots.length;

    function goToSlide(nextIndex) {
      index = (nextIndex + total) % total;
      track.style.transform = `translate3d(-${index * 100}%, 0, 0)`;
      dots.forEach((dot, i) => {
        const active = i === index;
        dot.classList.toggle("is-active", active);
        dot.setAttribute("aria-selected", active ? "true" : "false");
      });
    }

    if (prevBtn) prevBtn.addEventListener("click", () => goToSlide(index - 1));
    if (nextBtn) nextBtn.addEventListener("click", () => goToSlide(index + 1));
    dots.forEach((dot) => {
      dot.addEventListener("click", () => goToSlide(parseInt(dot.dataset.slide || "0", 10)));
    });

    if (viewport) {
      let startX = 0;
      viewport.addEventListener(
        "touchstart",
        (e) => {
          startX = e.changedTouches[0].clientX;
        },
        { passive: true }
      );
      viewport.addEventListener(
        "touchend",
        (e) => {
          const deltaX = e.changedTouches[0].clientX - startX;
          if (Math.abs(deltaX) > 42) {
            goToSlide(deltaX < 0 ? index + 1 : index - 1);
          }
        },
        { passive: true }
      );
    }
  }

  /* ------------------------------------------------------------------------
     11. Accessible FAQ Accordion
  ------------------------------------------------------------------------ */
  function initFaqAccordion() {
    const triggers = Array.from(document.querySelectorAll(".faq-trigger"));
    triggers.forEach((btn) => {
      btn.addEventListener("click", () => {
        const expanded = btn.getAttribute("aria-expanded") === "true";
        const panelId = btn.getAttribute("aria-controls");
        const panel = panelId ? document.getElementById(panelId) : null;

        // Close sibling panels for clean single-open rhythm
        triggers.forEach((otherBtn) => {
          if (otherBtn !== btn) {
            otherBtn.setAttribute("aria-expanded", "false");
            const otherPanel = document.getElementById(otherBtn.getAttribute("aria-controls"));
            if (otherPanel) otherPanel.classList.remove("is-open");
          }
        });

        btn.setAttribute("aria-expanded", expanded ? "false" : "true");
        if (panel) panel.classList.toggle("is-open", !expanded);
      });
    });
  }

  /* ------------------------------------------------------------------------
     12. Form Validation (Newsletter & Trailer Alert Forms)
  ------------------------------------------------------------------------ */
  function wireEmailForm(formId, inputId, feedbackId, successMessage) {
    const form = document.getElementById(formId);
    const input = document.getElementById(inputId);
    const feedback = document.getElementById(feedbackId);
    if (!form || !input || !feedback) return;

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const val = input.value.trim();

      if (!emailRegex.test(val)) {
        feedback.textContent = "Please enter a valid email address.";
        feedback.className = "form-feedback is-error";
        input.focus();
        return;
      }

      /* Backend Integration Point (e.g. Formspree / Custom API):
         fetch("https://formspree.io/f/YOUR_FORM_ID", {
           method: "POST",
           headers: { "Content-Type": "application/json", Accept: "application/json" },
           body: JSON.stringify({ email: val })
         });
      */

      feedback.textContent = successMessage.replace("{email}", val);
      feedback.className = "form-feedback is-success";
      form.reset();
    });
  }

  /* ------------------------------------------------------------------------
     Boot Application
  ------------------------------------------------------------------------ */
  document.addEventListener("DOMContentLoaded", function () {
    initHeroCharacterCutout();
    initScrollAndNav();
    initCursorRing();
    initHeroParallax();
    initButtonRipples();
    initScrollReveals();
    initOverlaysAndModals();

    const selectMovie = initCatalogAndBooking();
    initSearch(selectMovie);

    initTestimonials();
    initFaqAccordion();

    wireEmailForm(
      "ctaNewsletterForm",
      "ctaEmailInput",
      "ctaNewsletterFeedback",
      "Confirmed — premiere access drops will be sent to {email}."
    );
    wireEmailForm(
      "footerNewsletterForm",
      "footerEmailInput",
      "footerNewsletterFeedback",
      "Subscribed {email} to REDREEL alerts."
    );
    wireEmailForm(
      "trailerNotifyForm",
      "trailerEmailInput",
      "trailerNotifyFeedback",
      "Reminder locked for {email} — watch your inbox Nov 28."
    );
  });
})();
